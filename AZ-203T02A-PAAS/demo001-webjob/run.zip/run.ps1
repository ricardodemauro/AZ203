Write-Output ("Hello " + $env:USERNAME)
Write-Output ("Look at the time " + (Get-Date -Format g))