Write-Output ("Hello2 " + $env:USERNAME)
Write-Output ("Look at the time2 " + (Get-Date -Format g))